public class Nodo {
    int x,y;
    Nodo siguiente;
    public Nodo(int x, int y){
        this.x=x;
        this.y=y;
        this.siguiente=null;
    }

}
