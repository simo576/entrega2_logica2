public class App {
    public static void main(String[] args) throws Exception {
        ListaDobleUI ui = new ListaDobleUI();
        ui.menu();
    }
}
