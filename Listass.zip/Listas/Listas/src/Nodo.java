public class Nodo {
    int dato; //Contenido del nodo
    Nodo siguiente; //puntero del sigueinte nodo

    public Nodo(int dato){
        this.dato=dato;
        this.siguiente=null;

    }

}
